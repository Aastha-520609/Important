package com.bookingservice.booking_service.Entity;

public enum BookingStatus {
    PENDING,   
    CONFIRMED, 
    CANCELLED 
}
