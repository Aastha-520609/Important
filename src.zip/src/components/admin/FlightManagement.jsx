import React, { useState, useEffect } from "react";
import AddFlightForm from "./AddFlightForm";
import EditFlightForm from "./EditFlightForm";

const API_BASE = "http://localhost:8080/flights";

const getToken = () => localStorage.getItem("token");

const FlightManagement = () => {
  const [flights, setFlights] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editFlight, setEditFlight] = useState(null);

  useEffect(() => {
    fetch(`${API_BASE}/all`, {
      headers: { Authorization: `Bearer ${getToken()}` },
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setFlights(data);
        else setFlights([]); 
      })
      .catch(() => setFlights([]));
  }, []);

  // Add Flight
  const handleAddFlight = async (flight) => {
    try {
      await fetch(`${API_BASE}/add`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${getToken()}`,
        },
        body: JSON.stringify([flight]),
      });
      setShowAdd(false);
      window.location.reload();
    } catch {
      alert("Failed to add flight");
    }
  };

  // Edit Flight
  const handleEditFlight = async (updatedFlight) => {
    try {
      await fetch(`${API_BASE}/update/${updatedFlight.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${getToken()}`,
        },
        body: JSON.stringify(updatedFlight),
      });
      setEditFlight(null);
      window.location.reload();
    } catch {
      alert("Failed to update flight");
    }
  };

  // Delete Flight
  const handleDeleteFlight = async (id) => {
    if (window.confirm("Are you sure you want to delete this flight?")) {
      try {
        await fetch(`${API_BASE}/delete/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${getToken()}` },
        });
        setFlights(flights.filter((f) => f.id !== id));
      } catch {
        alert("Failed to delete flight");
      }
    }
  };

  return (
    <div>
      <div style={{ marginBottom: "1rem" }}>
        <button onClick={() => setShowAdd(true)}>Add Flight</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>Airline</th>
            <th>Flight No</th>
            <th>Source</th>
            <th>Destination</th>
            <th>Date</th>
            <th>Departure</th>
            <th>Arrival</th>
            <th>Price</th>
            <th>Seats</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {Array.isArray(flights) && flights.length > 0 ? (
            flights.map((flight) => (
              <tr key={flight.id}>
                <td>{flight.airlineName}</td>
                <td>{flight.flightNumber}</td>
                <td>{flight.source}</td>
                <td>{flight.destination}</td>
                <td>{flight.flightDate}</td>
                <td>{flight.departureTime}</td>
                <td>{flight.arrivalTime}</td>
                <td>{flight.price}</td>
                <td>{flight.seatsAvailable}</td>
                <td>
                  <button onClick={() => setEditFlight(flight)}>Edit</button>
                  <button onClick={() => handleDeleteFlight(flight.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="10" style={{ textAlign: "center" }}>
                No flights found.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {showAdd && (
        <AddFlightForm
          onAdd={handleAddFlight}
          onClose={() => setShowAdd(false)}
        />
      )}
      {editFlight && (
        <EditFlightForm
          flight={editFlight}
          onEdit={handleEditFlight}
          onClose={() => setEditFlight(null)}
        />
      )}
    </div>
  );
};

export default FlightManagement;