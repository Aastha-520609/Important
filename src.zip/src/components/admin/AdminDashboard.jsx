//import React, { useState } from "react";
import FlightManagement from "./FlightManagement";
import '../../styles/admin/AdminDashboard.css';

const AdminDashboard = () => {
  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <FlightManagement />
    </div>
  );
};

export default AdminDashboard;