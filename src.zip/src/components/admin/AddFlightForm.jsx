import React, { useState } from "react";

const AddFlightForm = ({ onAdd, onClose }) => {
  const [flight, setFlight] = useState({
    airlineName: "",
    flightNumber: "",
    source: "",
    destination: "",
    flightDate: "",
    departureTime: "",
    arrivalTime: "",
    price: "",
    seatsAvailable: "",
  });

  const handleChange = (e) => {
    setFlight({ ...flight, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Convert price and seatsAvailable to numbers
    onAdd({
      ...flight,
      price: Number(flight.price),
      seatsAvailable: Number(flight.seatsAvailable),
    });
  };

  return (
    <div className="modal">
      <form className="flight-form" onSubmit={handleSubmit}>
        <h3>Add Flight</h3>
        <input name="airlineName" placeholder="Airline Name" value={flight.airlineName} onChange={handleChange} required />
        <input name="flightNumber" placeholder="Flight Number" value={flight.flightNumber} onChange={handleChange} required />
        <input name="source" placeholder="Source" value={flight.source} onChange={handleChange} required />
        <input name="destination" placeholder="Destination" value={flight.destination} onChange={handleChange} required />
        <input type="date" name="flightDate" value={flight.flightDate} onChange={handleChange} required />
        <input type="time" name="departureTime" value={flight.departureTime} onChange={handleChange} required />
        <input type="time" name="arrivalTime" value={flight.arrivalTime} onChange={handleChange} required />
        <input type="number" name="price" placeholder="Price" value={flight.price} onChange={handleChange} required />
        <input type="number" name="seatsAvailable" placeholder="Seats Available" value={flight.seatsAvailable} onChange={handleChange} required />
        <button type="submit">Add</button>
        <button type="button" onClick={onClose}>Cancel</button>
      </form>
    </div>
  );
};

export default AddFlightForm;