import React from 'react';
import '../../styles/user/WhyUs.css';

const features = [
  {
    title: 'Easy Booking',
    desc: 'We offer easy and convenient flight bookings with attractive offers.',
    icon: '✈️',
  },
  {
    title: 'Lowest Price',
    desc: 'We ensure low rates on hotel reservation, holiday packages and on flight tickets.',
    icon: '💸',
  },
  {
    title: 'Instant Refund',
    desc: 'Get instant refunds effortlessly on your travel bookings with us.',
    icon: '💰',
  },
  {
    title: '24/7 Support',
    desc: 'Get assistance 24/7 on any kind of travel related query. We are happy to assist you.',
    icon: '📞',
  },
  {
    title: 'Exciting Deals',
    desc: 'Enjoy exciting deals on flights, hotels, buses, car rental and tour packages.',
    icon: '🔥',
  }
];

export default function WhyUs() {
  return (
    <section className="whyus-section">
      <h2 className="whyus-title">WHY US?</h2>
      <div className="whyus-grid">
        {features.map((feature, index) => (
          <div key={index} className="whyus-card">
            <div className="whyus-icon">{feature.icon}</div>
            <h3 className="whyus-heading">{feature.title}</h3>
            <p className="whyus-description">{feature.desc}</p>
          </div>
        ))}
      </div>
      <div className="trust-rating">
        <span className="trust-label">Great</span>
        <span className="trust-stars">⭐⭐⭐⭐☆</span>
        <span className="trust-reviews">12,206 reviews on</span>
        <img src="" alt="Reviews" className="trust-logo" />
      </div>
    </section>
  );
}
