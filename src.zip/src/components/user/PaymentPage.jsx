import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

const API_BASE = "http://localhost:8080";

const PaymentPage = () => {
  const query = new URLSearchParams(useLocation().search);
  const bookingId = query.get("bookingId");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const processPayment = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch(`${API_BASE}/payments/process`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: token ? `Bearer ${token}` : undefined,
          },
          body: JSON.stringify({ bookingId: Number(bookingId) }),
        });
        if (!res.ok) {
          const msg = await res.text();
          throw new Error(msg);
        }
        const data = await res.json();
        if (data.stripeCheckoutUrl) {
          window.location.href = data.stripeCheckoutUrl;
        } else {
          setError("Payment initiation failed.");
        }
      } catch (err) {
        setError(err.message || "Payment failed");
      }
      setLoading(false);
    };
    if (bookingId) processPayment();
    else setError("No booking ID found.");
  }, [bookingId]);

  return (
    <div className="payment-container">
      {loading && <div>Redirecting to payment...</div>}
      {error && <div className="error">{error}</div>}
    </div>
  );
};

export default PaymentPage;