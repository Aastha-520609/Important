import React from 'react';
import '../../styles/user/FlightOffers.css';

const flightOffers = [
  {
    title: "New User Offer on",
    highlight: "First Flight",
    code: "EMTFIRST",
    desc: "Register and Get Discount on Booking First Flight with Us",
    validTill: "31st May, 2025",
    img: "/offers/first-flight.png"
  },
  {
    title: "More comfort at attractive fares on",
    highlight: "Air France and KLM",
    code: "",
    desc: "Fly Air France Premium & KLM Premium Comfort: Spacious seats, priority boarding, gourmet meals, and more—all at unbeatable fares.",
    validTill: "",
    img: "/offers/klm.png"
  },
  {
    title: "Get Amazing Discount on",
    highlight: "Air Arabia",
    code: "EMTARABIA",
    desc: "Book AirArabia Round-Trip Flights and Get Up to 15% OFF*",
    validTill: "",
    img: "/offers/air-arabia.png"
  }
];

export default function FlightOffers() {
  return (
    <section className="flight-offers-section">
      <h2 className="flight-offers-title">FLIGHT BOOKING OFFERS</h2>
      <div className="flight-offers-grid">
        {flightOffers.map((offer, index) => (
          <div className="flight-offer-card" key={index}>
            <div className="offer-text">
              <p className="offer-title">{offer.title}</p>
              <h3 className="offer-highlight">{offer.highlight}</h3>
              {offer.code && (
                <div className="offer-code">
                  Use Code: <span>{offer.code}</span>
                </div>
              )}
              <p className="offer-desc">{offer.desc}</p>
              {offer.validTill && <p className="offer-valid">Valid till: {offer.validTill}</p>}
            </div>
            <div className="offer-img">
              <img src={offer.img} alt={offer.highlight} />
            </div>
          </div>
        ))}
      </div>
      <button className="view-all-btn">View All Flight Offers</button>
    </section>
  );
}
