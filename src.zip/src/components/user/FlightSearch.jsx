import React, { useState } from "react";
import "../../styles/user/FlightSearch.css";

const indianAirportCities = [
  "Delhi",
  "Mumbai",
  "Bangalore",
  "Chennai",
  "Kolkata",
  "Hyderabad",
  "Ahmedabad",
  "Pune",
  "Goa",
  "Jaipur",
  "Lucknow",
  "Guwahati",
  "Kochi",
  "Amritsar",
  "Patna",
  "Bhubaneswar",
  "Indore",
  "Nagpur",
  "Coimbatore",
  "Trivandrum"
];

const API_BASE = "http://localhost:8080/flights";

const FlightSearch = () => {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [flights, setFlights] = useState([]);
  const [loading, setLoading] = useState(false);
  const [noResults, setNoResults] = useState(false);

  const [fromSuggestions, setFromSuggestions] = useState([]);
  const [toSuggestions, setToSuggestions] = useState([]);

  const handleFromChange = (e) => {
    const value = e.target.value;
    setFrom(value);
    if (value.length > 0) {
      setFromSuggestions(
        indianAirportCities.filter(
          (city) =>
            city.toLowerCase().startsWith(value.toLowerCase()) &&
            city !== to
        )
      );
    } else {
      setFromSuggestions([]);
    }
  };

  const handleToChange = (e) => {
    const value = e.target.value;
    setTo(value);
    if (value.length > 0) {
      setToSuggestions(
        indianAirportCities.filter(
          (city) =>
            city.toLowerCase().startsWith(value.toLowerCase()) &&
            city !== from
        )
      );
    } else {
      setToSuggestions([]);
    }
  };

  const handleFromSelect = (city) => {
    setFrom(city);
    setFromSuggestions([]);
  };

  const handleToSelect = (city) => {
    setTo(city);
    setToSuggestions([]);
  };

  const handleSearch = async () => {
    setLoading(true);
    setNoResults(false);
    setFlights([]);
    if (!date || !from || !to) {
      setLoading(false);
      alert("Please select source, destination, and departure date.");
      return;
    }
    try {
      const res = await fetch(
        `${API_BASE}/search?source=${encodeURIComponent(from)}&destination=${encodeURIComponent(to)}&flightDate=${date}`
      );
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        setFlights(data);
      } else {
        setNoResults(true);
      }
    } catch {
      setNoResults(true);
    }
    setLoading(false);
  };

  const handleBook = (flight) => {
    alert(`Booking flight: ${flight.airlineName} (${flight.flightNumber})`);
  };

  return (
    <div className="search-container">
      <div className="trip-types">
        <button className="active">One Way</button>
      </div>

      <div className="search-box">
        <div className="input-group" style={{ position: "relative" }}>
          <label>From</label>
          <input
            type="text"
            value={from}
            onChange={handleFromChange}
            placeholder="Enter city"
            className="select-input"
            autoComplete="off"
          />
          {fromSuggestions.length > 0 && (
            <ul className="suggestion-list">
              {fromSuggestions.map((city) => (
                <li key={city} onClick={() => handleFromSelect(city)}>
                  {city}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="input-group" style={{ position: "relative" }}>
          <label>To</label>
          <input
            type="text"
            value={to}
            onChange={handleToChange}
            placeholder="Enter city"
            className="select-input"
            autoComplete="off"
          />
          {toSuggestions.length > 0 && (
            <ul className="suggestion-list">
              {toSuggestions.map((city) => (
                <li key={city} onClick={() => handleToSelect(city)}>
                  {city}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="input-group">
          <label>Departure Date</label>
          <input
            type="date"
            className="date-input"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>

        <button className="search-button" onClick={handleSearch}>SEARCH</button>
      </div>

      {/* Results Section */}
      <div className="search-results">
        {loading && <div>Loading...</div>}
        {noResults && <div>No flights found.</div>}
        {flights.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Airline</th>
                <th>Flight No</th>
                <th>Source</th>
                <th>Destination</th>
                <th>Date</th>
                <th>Departure</th>
                <th>Arrival</th>
                <th>Price</th>
                <th>Seats</th>
                <th>Book</th>
              </tr>
            </thead>
            <tbody>
              {flights.map((flight) => (
                <tr key={flight.id}>
                  <td>{flight.airlineName}</td>
                  <td>{flight.flightNumber}</td>
                  <td>{flight.source}</td>
                  <td>{flight.destination}</td>
                  <td>{flight.flightDate}</td>
                  <td>{flight.departureTime}</td>
                  <td>{flight.arrivalTime}</td>
                  <td>{flight.price}</td>
                  <td>{flight.seatsAvailable}</td>
                  <td>
                    <button onClick={() => handleBook(flight)}>Book</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default FlightSearch;