import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../styles/user/FlightSearch.css";

const indianAirportCities = [
  "Delhi", "Mumbai", "Bangalore", "Chennai", "Kolkata", "Hyderabad",
  "Ahmedabad", "Pune", "Goa", "Jaipur", "Lucknow", "Guwahati", "Kochi",
  "Amritsar", "Patna", "Bhubaneswar", "Indore", "Nagpur", "Coimbatore", "Trivandrum"
];

const FlightSearch = () => {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [fromSuggestions, setFromSuggestions] = useState([]);
  const [toSuggestions, setToSuggestions] = useState([]);
  const navigate = useNavigate();

  const handleFromChange = (e) => {
    const value = e.target.value;
    setFrom(value);
    if (value.length > 0) {
      setFromSuggestions(
        indianAirportCities.filter(
          (city) =>
            city.toLowerCase().startsWith(value.toLowerCase()) &&
            city !== to
        )
      );
    } else {
      setFromSuggestions([]);
    }
  };

  const handleToChange = (e) => {
    const value = e.target.value;
    setTo(value);
    if (value.length > 0) {
      setToSuggestions(
        indianAirportCities.filter(
          (city) =>
            city.toLowerCase().startsWith(value.toLowerCase()) &&
            city !== from
        )
      );
    } else {
      setToSuggestions([]);
    }
  };

  const handleFromSelect = (city) => {
    setFrom(city);
    setFromSuggestions([]);
  };

  const handleToSelect = (city) => {
    setTo(city);
    setToSuggestions([]);
  };

  const handleSearch = () => {
    if (!date || !from || !to) {
      alert("Please select source, destination, and departure date.");
      return;
    }
    navigate(`/results?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${date}`);
  };

  return (
    <div className="search-container">
      <div className="trip-types">
        <button className="active">One Way</button>
      </div>

      <div className="search-box">
        <div className="input-group" style={{ position: "relative" }}>
          <label>From</label>
          <input
            type="text"
            value={from}
            onChange={handleFromChange}
            placeholder="Enter city"
            className="select-input"
            autoComplete="off"
          />
          {fromSuggestions.length > 0 && (
            <ul className="suggestion-list">
              {fromSuggestions.map((city) => (
                <li key={city} onClick={() => handleFromSelect(city)}>
                  {city}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="input-group" style={{ position: "relative" }}>
          <label>To</label>
          <input
            type="text"
            value={to}
            onChange={handleToChange}
            placeholder="Enter city"
            className="select-input"
            autoComplete="off"
          />
          {toSuggestions.length > 0 && (
            <ul className="suggestion-list">
              {toSuggestions.map((city) => (
                <li key={city} onClick={() => handleToSelect(city)}>
                  {city}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="input-group">
          <label>Departure Date</label>
          <input
            type="date"
            className="date-input"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>

        <button className="search-button" onClick={handleSearch}>SEARCH</button>
      </div>
    </div>
  );
};

export default FlightSearch;