import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../../styles/user/Login.css"; // Reuse the login theme

const API_BASE = "http://localhost:8080";

const BookingPage = () => {
  const { state } = useLocation();
  const flight = state?.flight;
  const navigate = useNavigate();

  const [form, setForm] = useState({
    passengerName: "",
    age: "",
    email: "",
    contactNumber: "",
    seatsBooked: 1,
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (!flight) {
    return (
      <div className="login-container">
        <h2>No flight selected.</h2>
      </div>
    );
  }

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleBooking = async () => {
    setError("");
    setLoading(true);
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(`${API_BASE}/bookings/book`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : undefined,
        },
        body: JSON.stringify({
          ...form,
          age: Number(form.age),
          seatsBooked: Number(form.seatsBooked),
          flightId: flight.id,
        }),
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg);
      }
      const booking = await res.json();
      navigate(`/payment?bookingId=${booking.id}`);
    } catch (err) {
      setError(err.message || "Booking failed");
    }
    setLoading(false);
  };

  return (
    <div className="login-container">
      <h2>Book Flight: {flight.airlineName} ({flight.flightNumber})</h2>
      <input
        type="text"
        name="passengerName"
        placeholder="Name"
        value={form.passengerName}
        onChange={handleChange}
        required
      />
      <input
        type="number"
        name="age"
        placeholder="Age"
        value={form.age}
        min={1}
        max={120}
        onChange={handleChange}
        required
      />
      <input
        type="email"
        name="email"
        placeholder="Email"
        value={form.email}
        onChange={handleChange}
        required
      />
      <input
        type="text"
        name="contactNumber"
        placeholder="Contact Number"
        value={form.contactNumber}
        onChange={handleChange}
        required
      />
      <input
        type="number"
        name="seatsBooked"
        placeholder="No of Seats"
        min={1}
        max={flight.seatsAvailable}
        value={form.seatsBooked}
        onChange={handleChange}
        required
      />
      <button className="login-btn" onClick={handleBooking} disabled={loading}>
        {loading ? "Booking..." : "Book & Pay"}
      </button>
      {error && <div className="error-message">{error}</div>}
    </div>
  );
};

export default BookingPage;