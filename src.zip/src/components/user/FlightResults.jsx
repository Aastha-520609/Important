import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../../styles/user/FlightResults.css";

const API_BASE = "http://localhost:8080/flights";

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

const FlightResults = () => {
  const query = useQuery();
  const from = query.get("from");
  const to = query.get("to");
  const date = query.get("date");

  const [flights, setFlights] = useState([]);
  const [loading, setLoading] = useState(false);
  const [noResults, setNoResults] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchFlights = async () => {
      setLoading(true);
      setNoResults(false);
      try {
        const token = localStorage.getItem("token");
        const res = await fetch(
          `${API_BASE}/search?source=${encodeURIComponent(from)}&destination=${encodeURIComponent(to)}&flightDate=${date}`,
          {
            headers: {
              Authorization: token ? `Bearer ${token}` : undefined,
            },
          }
        );
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setFlights(data);
        } else {
          setNoResults(true);
        }
      } catch {
        setNoResults(true);
      }
      setLoading(false);
    };
    fetchFlights();
  }, [from, to, date]);

  const handleBook = (flight) => {
    navigate("/book", { state: { flight } });
  };

  return (
    <div className="results-container">
      <div className="search-results">
        <h2>Flight Results</h2>
        {loading && <div>Loading...</div>}
        {noResults && <div>No flights found.</div>}
        {flights.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Airline</th>
                <th>Flight No</th>
                <th>Source</th>
                <th>Destination</th>
                <th>Date</th>
                <th>Departure</th>
                <th>Arrival</th>
                <th>Price</th>
                <th>Seats</th>
                <th>Book</th>
              </tr>
            </thead>
            <tbody>
              {flights.map((flight) => (
                <tr key={flight.id}>
                  <td>{flight.airlineName}</td>
                  <td>{flight.flightNumber}</td>
                  <td>{flight.source}</td>
                  <td>{flight.destination}</td>
                  <td>{flight.flightDate}</td>
                  <td>{flight.departureTime}</td>
                  <td>{flight.arrivalTime}</td>
                  <td>{flight.price}</td>
                  <td>{flight.seatsAvailable}</td>
                  <td>
                    <button onClick={() => handleBook(flight)}>Book</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default FlightResults;